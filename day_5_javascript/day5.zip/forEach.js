// forEach is a higher order function
[1,2,3].forEach(function(){
  console.log("Hello");
});


[1,2,3].forEach(function(element){
  console.log(element);
});
