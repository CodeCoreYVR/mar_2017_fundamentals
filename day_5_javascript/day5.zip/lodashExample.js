// lodash
// underscore
// jquery

// lodash
let newArray = _.compact([false,'',0,null]);
console.log(newArray);
